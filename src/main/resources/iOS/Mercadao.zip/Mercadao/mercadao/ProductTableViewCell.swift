//
//  ProductTableViewCell.swift
//  Mercadao
//
//  Created by Leandro Luizari on 21/05/17.
//  Copyright © 2017 Leandro Luizari. All rights reserved.
//

import UIKit

class ProductTableViewCell: UITableViewCell {

    
    
    @IBOutlet weak var imageProduct: UIImageView!
    @IBOutlet weak var labelDescription: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func loadImage(product: Product) {
        
        self.imageProduct.image = nil
        
        if (self.fileExistsAtPathInAppDocuments(filename: product.key)) {
            
            let pathToFile = getPathToFileInAppDocuments(path: product.key)
            let image    = UIImage(contentsOfFile: pathToFile)
            
            self.imageProduct.image = image
        }
        else {
            
            self.startLoader(self.imageProduct)
            
            guard let url = URL(string: product.imageUrl) else { return }
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                
                DispatchQueue.main.async {
                    
                    if error != nil {
                        
                        self.imageProduct.image = nil
                        return
                    }
                    
                    guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                        
                        self.imageProduct.image = nil
                        return
                    }
                    
                    self.imageProduct.image = UIImage(data: data!)
                    self.saveFileInDocuments(file: data! as NSData, name: product.key)
                    self.stopLoader(self.imageProduct)
                    
                    
                }
                
                }.resume()
        }
    }
    
    func getPathToFileInAppDocuments(path:String) -> String {
        
        let documentsDir:NSString = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
        return "\(documentsDir)/\(path)"
    }
    func fileExistsAtPathInAppDocuments(filename:String) -> Bool {
        
        let manager = FileManager.default
        
        let path = getPathToFileInAppDocuments(path: filename)
        
        return manager.fileExists(atPath: path)
    }
    func saveFileInDocuments(file:NSData, name:String) {
        //Get Documents folder
        let documentsDir:NSString = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
        file.write(toFile: "\(documentsDir)/\(name)", atomically: true)
    }
    
    func startLoader(_ view: UIView) {
        
        let viewWidth = view.frame.size.width
        let viewHeight = view.frame.size.height
        
        let overlay = UIView(frame: CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight))
        overlay.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5)
        overlay.tag = 1
        view.addSubview(overlay)
        
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
        spinner.center = CGPoint(x: viewWidth/2, y: viewHeight/2)
        overlay.addSubview(spinner)
        spinner.startAnimating()
        
    }
    func stopLoader(_ view: UIView) {
        
        for subView in view.subviews {
            if (subView.tag == 1) {
                subView.removeFromSuperview()
            }
        }
    }
}
