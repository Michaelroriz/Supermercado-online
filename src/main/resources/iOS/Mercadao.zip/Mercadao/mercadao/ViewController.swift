//
//  ViewController.swift
//  Mercadao
//
//  Created by Leandro Luizari on 05/05/17.
//  Copyright © 2017 Leandro Luizari. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage

class ViewController: UIViewController, UIWebViewDelegate, BarcodeScannerCodeDelegate, BarcodeScannerErrorDelegate, BarcodeScannerDismissalDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    var product:Product?
    var pickerCategory:UIPickerView? = nil
    var categories = ["Alimentos", "Bebidas", "Produtos de Limpeza", "Higiene", "Perfumaria", "Jogos", "Remédios", "Tabacaria"]
    
    enum State {
        
        case Search
        case Save
        
    }
    
    @IBOutlet weak var labelName: UITextField!
    @IBOutlet weak var textStock: UITextField!
    @IBOutlet weak var textPrice: UITextField!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var labelDescription: UITextView!
    
    @IBOutlet weak var textCategory: UITextField!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.initWebview()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(ViewController.dismissKeyboard))
        self.view.addGestureRecognizer(tap)
        
        self.labelDescription.layer.borderColor = UIColor.lightGray.cgColor
        
        self.setupCategoryPicker()
        
        if (self.product == nil) {
            
            self.setState(state: State.Search)
        }
        else {
            
            self.loadProduct(product: self.product!)
        }
    }
    
    func setState(state: State) {
        
        self.navigationItem.rightBarButtonItems = []
        
        if (state == State.Save) {
            
            let save = UIBarButtonItem(title: "Salvar", style: .plain, target: self, action: #selector(onButtonSave))
            self.navigationItem.rightBarButtonItems = [save]
        }
        else {
            
            let search = UIBarButtonItem(barButtonSystemItem: .search, target: self, action: #selector(onButtonSearch))
            self.navigationItem.rightBarButtonItems = [search]
        }
    }
    
    func dismissKeyboard() {
        self.view.endEditing(true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    enum CrawlingSite {
        
        case DigitEyes
        case Cosmos
        
    }
    
    //Webview
    var webview = UIWebView()
    var code = String()
    var crawlingWebsite = CrawlingSite.DigitEyes
    var hasLoadedBarcode = false
    
    func initWebview() {
        
        self.webview.delegate = self
        
        self.webview.frame = self.view.frame;
//        self.view.addSubview(self.webview)
    }
    
    func refreshProduct(code: String, crawlingSite: CrawlingSite) {
        
        var request:NSURLRequest? = nil
        
        self.code = code
        
        var url:URL!
        
        if (crawlingSite == CrawlingSite.DigitEyes) { url = URL(string: "http://www.digit-eyes.com/upcCode/\(code)") }
        else { url = URL(string: "https://cosmos.bluesoft.com.br/produtos/\(code)") }
        
        self.crawlingWebsite = crawlingSite
        
        request = NSURLRequest(url: url!)
        
        self.webview.loadRequest(request! as URLRequest)
        
        self.startLoader(self.navigationController!.view)
    }
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        
    }
    func webViewDidFinishLoad(_ webView: UIWebView) {
        
        if (self.crawlingWebsite == CrawlingSite.DigitEyes) {
            
            parseHtml()
        }
        else {
            
            parseHtml2()
        }

    }
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        
        print(error.localizedDescription)
    }

    func parseHtml() {
        
        self.stopLoader(self.navigationController!.view)
        
        let docHtml = self.webview.stringByEvaluatingJavaScript(from: "document.documentElement.outerHTML")
        let pontosHtmlData = docHtml!.data(using: String.Encoding.utf8)

        let parser = TFHpple(htmlData: pontosHtmlData as Data!)

        let titleQuery = "//h2[@id='description']"
        let titleElements = parser?.search(withXPathQuery: titleQuery) as! [TFHppleElement]
        var title = ""
        for element in titleElements { title = element.content }
        
        if (title == "") {
            
            self.refreshProduct(code: self.code, crawlingSite: CrawlingSite.Cosmos)
            return
        }
        
        let descriptionQuery = "//td[@id='instructions']"
        let decriptionElements = parser?.search(withXPathQuery: descriptionQuery) as! [TFHppleElement]
        var description = ""
        for element in decriptionElements { description = element.content }
        
        let imageQuery = "//table[@class='t2']/tbody/tr/td/img"
        let imageElements = parser?.search(withXPathQuery: imageQuery) as! [TFHppleElement]
        var image = ""
        for element in imageElements {
            
            if let attributes = element.attributes as? [String:Any] {
                
                image = attributes["src"] as! String
            }
        
        }
        
        let product = Product()
        
        product.name = title
        product.itemDescription = description
        product.imageUrl = image
        
        self.loadProduct(product: product)
    }
    func parseHtml2() {
        
        self.stopLoader(self.navigationController!.view)
        
        let docHtml = self.webview.stringByEvaluatingJavaScript(from: "document.documentElement.outerHTML")
        let pontosHtmlData = docHtml!.data(using: String.Encoding.utf8)
        
        let parser = TFHpple(htmlData: pontosHtmlData as Data!)
        
        let titleQuery = "//div[contains(@class, 'products-details')]/h1"
        let titleElements = parser?.search(withXPathQuery: titleQuery) as! [TFHppleElement]
        var title = ""
        for element in titleElements {
            
            let parts = element.content.components(separatedBy: "\n")
            title = parts[1]
        }
        
        if (title == "") {
            
            self.clearScreen()
            
            return
        }
        
        let descriptionQuery = "//td[@id='instructions']"
        let decriptionElements = parser?.search(withXPathQuery: descriptionQuery) as! [TFHppleElement]
        var description = ""
        for element in decriptionElements { description = element.content }
        
        let imageQuery = "//img[contains(@alt, '\(code)')]"
        let imageElements = parser?.search(withXPathQuery: imageQuery) as! [TFHppleElement]
        var image = ""
        
        if let attributes = imageElements[0].attributes as? [String:Any] {
            
            image = attributes["src"] as! String
        }
        
        let product = Product()
        
        product.name = title
        product.itemDescription = description
        product.imageUrl = image
        
        self.loadProduct(product: product)

    }
    
    func setupCategoryPicker() {
        
        let picker = UIPickerView()
        
        picker.dataSource = self
        picker.delegate = self
        self.textCategory.inputView = picker
        
        self.pickerCategory = picker
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.categories.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return self.categories[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        self.textCategory.text = self.categories[row]
    }
    
    func startLoader(_ view: UIView) {
        
        let viewWidth = view.frame.size.width
        let viewHeight = view.frame.size.height
        
        let overlay = UIView(frame: CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight))
        overlay.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5)
        overlay.tag = 1
        view.addSubview(overlay)
        
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
        spinner.center = CGPoint(x: viewWidth/2, y: viewHeight/2)
        overlay.addSubview(spinner)
        spinner.startAnimating()
        
    }
    func stopLoader(_ view: UIView) {
        
        for subView in view.subviews {
            if (subView.tag == 1) {
                subView.removeFromSuperview()
            }
        }
    }
    func clearScreen() {
        
        self.labelName.text = ""
        self.labelDescription.text = ""
        self.textStock.text = ""
        self.textPrice.text = ""
        
        self.image.image = nil
    }
    func decodeISO88591(str:String) -> String {
        if let utfData = str.data(using: String.Encoding.isoLatin1) {
            if let utf = String(data: utfData, encoding: String.Encoding.utf8) {
                return utf
            }
        }
        return str
    }
    func loadProduct(product: Product) {
        
        self.setState(state: State.Save)
        
        self.labelName.text = decodeISO88591(str: product.name)
        
        let trimmedDescription = product.itemDescription.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        
        if (trimmedDescription == "") {
            
            self.labelDescription.text = decodeISO88591(str: product.name)
        }
        else {
            
            self.labelDescription.text = decodeISO88591(str: product.itemDescription)
        }
        
        self.textPrice.text = product.price
        self.textStock.text = product.stock
        self.textCategory.text = product.category
        
        if (product.key != "" && self.fileExistsAtPathInAppDocuments(filename: product.key)) {
            
            let pathToFile = getPathToFileInAppDocuments(path: product.key)
            let image    = UIImage(contentsOfFile: pathToFile)
            
            self.image.image = image
        }
        else {
            
            guard let url = URL(string: product.imageUrl) else { return }
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                
                if error != nil {
                    
                    self.webview.stopLoading()
                    self.image.image = nil
                    return
                }
                
                guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                    
                    self.webview.stopLoading()
                    self.image.image = nil
                    return
                }
                
                DispatchQueue.main.async {
                    
                    self.image.image = UIImage(data: data!)
                    
                    self.webview.stopLoading()
                }
                }.resume()

        }
    }
    
    func onButtonSave() {
        
        let title = self.labelName.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let description = self.labelDescription.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let stock = self.textStock.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let price = self.textPrice.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let category = self.textCategory.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        
        if (!title!.isEmpty && !description!.isEmpty && !stock!.isEmpty && !price!.isEmpty && !category!.isEmpty) {
            
            self.dismissKeyboard()
            self.startLoader(self.navigationController!.view)
            
            let product = Product()
            
            product.name = title!
            product.itemDescription = description!
            product.stock = stock!
            product.price = price!
            product.category = category!
            
            if (self.product == nil) {
                
                self.saveNewProduct(product: product)
            }
            else {
                
                product.key = self.product!.key
                
                self.updateProduct(product: product)
            }
            
            
        }
        
    }
    func updateProduct(product: Product) {
        
        self.startLoader(self.navigationController!.view)
        
        var ref: FIRDatabaseReference!
        ref = FIRDatabase.database().reference().child("products").child(product.key)
        
        let product = ["name": product.name, "description": product.itemDescription, "stock": product.stock, "price": product.price, "category" : product.category]
        
        ref.updateChildValues(product) { (error, ref) in
            
            self.stopLoader(self.navigationController!.view)
            
            self.navigationController?.popViewController(animated: true)
        }
    }
    func saveNewProduct(product: Product) {
        
        var ref: FIRDatabaseReference!
        ref = FIRDatabase.database().reference().child("/products")
        
        let product = ["name": product.name, "description": product.itemDescription, "stock": product.stock, "price": product.price, "category" : product.category]
        
        let pushRef = ref.childByAutoId()
        pushRef.setValue(product, withCompletionBlock: { (error, ref) in
            
            self.savaImage(key: pushRef.key)
        })

    }
    func saveImageUrl(key: String, url: String) {
        
        var ref: FIRDatabaseReference!
        ref = FIRDatabase.database().reference().child("/products/\(key)")
        
        let pushRef = ref.child("imageUrl")
        pushRef.setValue(url) { (erro, ref) in
            
            self.clearScreen()
            
            self.dismissKeyboard()
            
            self.stopLoader(self.navigationController!.view)
            
            self.navigationController?.popViewController(animated: true)
        }
    }
    func savaImage(key: String) {
        
        if (self.image.image == nil) {
            
            return
        }
        
        let data = UIImageJPEGRepresentation(self.image.image!, 0.8)!
       
        let metaData = FIRStorageMetadata()
        metaData.contentType = "image/jpg"
        
        let storageRef = FIRStorage.storage().reference()
        
        storageRef.child("\(key).jpg").put(data, metadata: metaData){(metaData,error) in
            
            if let error = error {
                
                print(error.localizedDescription)
                return
            }
            else{
                
                let downloadURL = metaData!.downloadURL()!.absoluteString
                
                self.saveImageUrl(key: key, url: downloadURL)
                
            }
            
        }
    }

    func onButtonSearch() {
        
        self.hasLoadedBarcode = false
        
        let controller = BarcodeScannerController()
        controller.codeDelegate = self
        controller.errorDelegate = self
        controller.dismissalDelegate = self
        
        present(controller, animated: true, completion: nil)
    }
    func barcodeScanner(_ controller: BarcodeScannerController, didCaptureCode code: String, type: String) {
        
        if (!hasLoadedBarcode) {
         
            self.refreshProduct(code: code, crawlingSite: CrawlingSite.DigitEyes)
            
            self.hasLoadedBarcode = true
        }
        
        controller.reset()
        controller.dismiss(animated: true, completion: nil)
    }
    func barcodeScanner(_ controller: BarcodeScannerController, didReceiveError error: Error) {
        print(error)
    }
    func barcodeScannerDidDismiss(_ controller: BarcodeScannerController) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    func getPathToFileInAppDocuments(path:String) -> String {
        
        let documentsDir:NSString = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
        return "\(documentsDir)/\(path)"
    }
    func fileExistsAtPathInAppDocuments(filename:String) -> Bool {
        
        let manager = FileManager.default
        
        let path = getPathToFileInAppDocuments(path: filename)
        
        return manager.fileExists(atPath: path)
    }

}

