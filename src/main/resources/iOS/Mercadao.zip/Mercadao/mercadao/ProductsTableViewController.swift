//
//  ProductsTableViewController.swift
//  Mercadao
//
//  Created by Leandro Luizari on 21/05/17.
//  Copyright © 2017 Leandro Luizari. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseStorage

class ProductsTableViewController: UITableViewController {

    //Attributes
    var products:[Product] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.delegate = self
        self.tableView.dataSource = self
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.refreshTableView()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func didAddProdcut() {
        
        self.refreshTableView()
    }
    
    //Tableview
    func refreshTableView() {
        
        self.startLoader(self.navigationController!.view)
        
        let ref = FIRDatabase.database().reference().child("/products")
        ref.observeSingleEvent(of: .value, with: { (snapshot) in

            self.products = []
            if let productsDict = snapshot.value as? [String: Any] {
                
                for (key, element) in productsDict {
                    
                    if let productDict = element as? [String: Any] {
                     
                        let itemDescription = productDict["description"] as! String
                        let imageUrl = productDict["imageUrl"] as! String
                        let name = productDict["name"] as! String
                        let price = productDict["price"] as! String
                        let stock = productDict["stock"] as! String
                        
                        let product = Product()
                        product.key = key
                        product.itemDescription = itemDescription
                        product.imageUrl = imageUrl
                        product.name = name
                        product.price = price
                        product.stock = stock
                        
                        if let category = productDict["category"] as? String {
                            
                            product.category = category
                        }
                        
                        self.products.append(product)
                    }
                }
            }
            
            self.tableView.reloadData()
            self.stopLoader(self.navigationController!.view)
            
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.products.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let product = self.products[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "personCell", for: indexPath) as! ProductTableViewCell
        
        cell.labelDescription.text = product.name
        cell.loadImage(product: product)
        
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let product = self.products[indexPath.row]
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"ViewController") as! ViewController
        
        viewController.product = product
        
        self.navigationController?.pushViewController(viewController, animated: true)
        
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
    }
    func tableView(tableView: UITableView!, canEditRowAtIndexPath indexPath: NSIndexPath!) -> Bool {
        return true
    }
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let product = self.products[indexPath.row]
        
        let deleteButton:UITableViewRowAction = UITableViewRowAction(style: UITableViewRowActionStyle.default, title: "Delete") { (action, indexPath) -> Void in
            
            //Ask user
            let title = "Remover"
            let message = "Certeza que deseja remover esse produto?"
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Remover", style: .default) { action in
                
                self.removeProduct(product: product)
            })
            
            alert.addAction(UIAlertAction(title: "Cancelar", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        return [deleteButton]
    }
    
    func removeProduct(product: Product) {
        
        var ref: FIRDatabaseReference!
        ref = FIRDatabase.database().reference().child("products").child(product.key)
        
        ref.removeValue { (error, ref) in
            
            self.removeImage(product: product)
        }
    }
    func removeImage(product: Product) {
        
        let storageRef = FIRStorage.storage().reference()
        
        storageRef.child("\(product.key).jpg").delete { (error) in
            
            self.refreshTableView()
        }
    }

    func startLoader(_ view: UIView) {
        
        let viewWidth = view.frame.size.width
        let viewHeight = view.frame.size.height
        
        let overlay = UIView(frame: CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight))
        overlay.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5)
        overlay.tag = 1
        view.addSubview(overlay)
        
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
        spinner.center = CGPoint(x: viewWidth/2, y: viewHeight/2)
        overlay.addSubview(spinner)
        spinner.startAnimating()
        
    }
    func stopLoader(_ view: UIView) {
        
        for subView in view.subviews {
            if (subView.tag == 1) {
                subView.removeFromSuperview()
            }
        }
    }
}
