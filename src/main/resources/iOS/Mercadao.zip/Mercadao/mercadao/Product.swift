//
//  Product.swift
//  Mercadao
//
//  Created by Leandro Luizari on 21/05/17.
//  Copyright © 2017 Leandro Luizari. All rights reserved.
//

import UIKit

class Product: NSObject {

    var key = ""
    var itemDescription = ""
    var imageUrl = ""
    var name = ""
    var price = ""
    var stock = ""
    var category = ""
}
